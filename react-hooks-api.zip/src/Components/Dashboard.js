import React, { useContext } from 'react';
import { UserContext } from './UserContext';
import useProfileData from './Profile';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { username } = useContext(UserContext);
  const { loading, userData } = useProfileData(); 

  return (
    <div>
      <h1>Dashboard</h1>
      <h2>Hi {username}</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <p>Name: {userData.name}</p>
          <p>Country: {userData.country}</p>
          <p>Gender: {userData.gender}</p>
          <p>PAN: {userData.pan}</p>
          <Link to="/hooks">click here to see the Difference Between Hooks</Link>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
