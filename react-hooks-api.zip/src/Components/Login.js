import React, { useContext ,useState} from 'react';
import { UserContext } from './UserContext';
import {useNavigate} from   'react-router-dom';
import './Login.css';

const Login = () => {
    const navigate = useNavigate();
    const { setUsername } = useContext(UserContext);
    const [inputValue, setInputValue] = useState('');
  
    const handleLogin = () => {
      setUsername(inputValue);
      navigate('/dashboard');
      
    };
  
    return (
      <div className='Login'>
        <h2>Login</h2>
        <input
          type="text"
          placeholder="Username"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <input
          type='password'
          placeholder='password'
          />
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  };
export default Login;
