import React, { useState, useRef } from 'react';


const StateComponent = () => {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <h1>State Component</h1>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};

const RefComponent = () => {
  const countRef = useRef(0);

  const increment = () => {
    countRef.current += 1;
    console.log('RefComponent count:', countRef.current);
  };

  return (
    <div>
      <h1>Ref Component</h1>
      <p>Count: {countRef.current}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
};



const DifferenceBetweenHooks = () => (
  <div>
    <StateComponent />
    <RefComponent />
  </div>
);

export default DifferenceBetweenHooks;
